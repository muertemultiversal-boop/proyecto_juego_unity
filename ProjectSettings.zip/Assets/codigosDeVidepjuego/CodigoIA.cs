using UnityEngine;

public class EnemigoIA : MonoBehaviour
{
    public float velocidad = 2f;
    public float rangoDeteccion = 4f;
    public float rangoAtaque = 1f;

    private Transform jugador;
    private Vector3 inicio;
    private bool derecha = true;

    private void Start()
    {
        inicio = transform.position;
    }

    private void Update()
    {
        // Busca al jugador si aún no lo tiene
        if (jugador == null)
        {
            GameObject obj = GameObject.FindWithTag("Player");
            if (obj != null) jugador = obj.transform;
        }

        if (jugador == null)
        {
            Patrullar();
            return;
        }

        float distancia = Vector2.Distance(transform.position, jugador.position);

        if (distancia <= rangoAtaque)
        {
            // Aquí llamas el daño al jugador cuando tengas ese sistema
            Debug.Log("Enemigo ataca al jugador");
        }
        else if (distancia <= rangoDeteccion)
        {
            Mover(jugador.position.x); // persigue
        }
        else
        {
            Patrullar();
        }
    }

    // Camina de un lado a otro cerca de su punto de inicio
    private void Patrullar()
    {
        float destino = derecha ? inicio.x + 2f : inicio.x - 2f;
        Mover(destino);

        if (Mathf.Abs(transform.position.x - destino) < 0.1f)
            derecha = !derecha;
    }

    // Mueve al enemigo hacia una posición X y voltea el sprite
    private void Mover(float destinoX)
    {
        float direccion = destinoX > transform.position.x ? 1f : -1f;
        transform.position += Vector3.right * direccion * velocidad * Time.deltaTime;

        Vector3 escala = transform.localScale;
        escala.x = Mathf.Abs(escala.x) * direccion;
        transform.localScale = escala;
    }
}